
WITH order_dates AS (
    SELECT
        customer_id,
        COUNT(order_id) AS total_orders,
        MIN(order_date) AS first_order,
        MAX(order_date) AS last_order
    FROM {{ ref('stg_sales') }}
    GROUP BY customer_id
),
order_frequency AS (
    SELECT
        customer_id,
        total_orders,
        first_order,
        last_order,
        CASE WHEN total_orders > 1 THEN
            (last_order - first_order) / NULLIF(total_orders - 1, 0)::numeric
        ELSE NULL END AS avg_days_between_orders
    FROM order_dates
)
SELECT
    customer_id,
    total_orders,
    first_order,
    last_order,
    avg_days_between_orders
FROM order_frequency
ORDER BY customer_id
