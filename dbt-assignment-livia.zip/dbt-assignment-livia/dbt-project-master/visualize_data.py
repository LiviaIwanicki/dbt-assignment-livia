import pandas as pd
from sqlalchemy import create_engine
import matplotlib.pyplot as plt
import seaborn as sns

# PostgreSQL connection string from DBT example
db_connection_url = "postgresql://u5h2s7shhkqeo5:pf373bc6d5cddc47f95a938f4914e895c868ca1e01fc5eeb79ad7413b71c6db40@c97r84s7psuajm.cluster-czrs8kj4isg7.us-east-1.rds.amazonaws.com:5432/d9snqvovhsjpqs"

# Create SQLAlchemy engine
engine = create_engine(db_connection_url)

# Test connection and list the tables
tables = pd.read_sql("SELECT table_name FROM information_schema.tables WHERE table_schema='public'", engine)
print(tables)

# Query sales data
sales_query = '''
SELECT order_date, SUM(total_price) as total_revenue, COUNT(order_id) as total_orders
FROM stg_sales
GROUP BY order_date
ORDER BY order_date;
'''
sales_data = pd.read_sql(sales_query, engine)

# Display the first few rows
print(sales_data.head())

# Plot total revenue over time
plt.figure(figsize=(10, 6))
sns.lineplot(data=sales_data, x='order_date', y='total_revenue', marker='o')
plt.title('Total Revenue Over Time')
plt.xlabel('Order Date')
plt.ylabel('Total Revenue ($)')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# Plot total orders over time
plt.figure(figsize=(10, 6))
sns.lineplot(data=sales_data, x='order_date', y='total_orders', marker='o', color='green')
plt.title('Total Orders Over Time')
plt.xlabel('Order Date')
plt.ylabel('Total Orders')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# Query top products by revenue
product_query = '''
SELECT p.product_name, SUM(s.total_price) as total_revenue
FROM stg_sales s
JOIN stg_products p ON s.product_id = p.product_id
GROUP BY p.product_name
ORDER BY total_revenue DESC
LIMIT 10;
'''
product_data = pd.read_sql(product_query, engine)

# Plot top products by revenue
plt.figure(figsize=(10, 6))
sns.barplot(data=product_data, x='total_revenue', y='product_name', palette='Blues_d')
plt.title('Top 10 Products by Revenue')
plt.xlabel('Total Revenue ($)')
plt.ylabel('Product')
plt.tight_layout()
plt.show()

# Query customer order frequency data
frequency_query = '''
WITH order_dates AS (
    SELECT
        customer_id,
        COUNT(order_id) AS total_orders,
        MIN(order_date) AS first_order,
        MAX(order_date) AS last_order
    FROM stg_sales
    GROUP BY customer_id
),
order_frequency AS (
    SELECT
        customer_id,
        total_orders,
        first_order,
        last_order,
        CASE WHEN total_orders > 1 THEN
            (last_order - first_order) / NULLIF(total_orders - 1, 0)::numeric
        ELSE NULL END AS avg_days_between_orders
    FROM order_dates
)
SELECT
    customer_id,
    total_orders,
    first_order,
    last_order,
    avg_days_between_orders
FROM order_frequency
ORDER BY customer_id;
'''

# Load the data into a DataFrame
frequency_data = pd.read_sql(frequency_query, engine)


#Plot Total Orders per Customer
plt.figure(figsize=(10, 6))
sns.barplot(data=frequency_data, x='customer_id', y='total_orders', palette='viridis')
plt.title('Total Orders per Customer')
plt.xlabel('Customer ID')
plt.ylabel('Total Orders')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

#Plot Average Days Between Orders per Customer
plt.figure(figsize=(10, 6))
sns.barplot(data=frequency_data, x='customer_id', y='avg_days_between_orders', palette='coolwarm')
plt.title('Average Days Between Orders per Customer')
plt.xlabel('Customer ID')
plt.ylabel('Avg Days Between Orders')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()


# Query top 10 customers by revenue
top_customers_query = '''
WITH customer_revenue AS (
    SELECT
        customer_id,
        COUNT(order_id) AS total_orders,
        SUM(total_price) AS total_revenue
    FROM stg_sales
    GROUP BY customer_id
)
SELECT
    customer_id,
    total_orders,
    total_revenue
FROM customer_revenue
ORDER BY total_revenue DESC
LIMIT 10;
'''

# Load the data into a DataFrame
top_customers_data = pd.read_sql(top_customers_query, engine)

#Plot Total Revenue for Top 10 Customers

plt.figure(figsize=(10, 6))
sns.barplot(data=top_customers_data, x='total_revenue', y='customer_id', palette='Blues_d')
plt.title('Top 10 Customers by Total Revenue')
plt.xlabel('Total Revenue ($)')
plt.ylabel('Customer ID')
plt.tight_layout()
plt.show()

#Total Orders for Top 10 Customers

plt.figure(figsize=(10, 6))
sns.barplot(data=top_customers_data, x='total_orders', y='customer_id', palette='Greens_d')
plt.title('Total Orders for Top 10 Customers')
plt.xlabel('Total Orders')
plt.ylabel('Customer ID')
plt.tight_layout()
plt.show()

# Query monthly data for orders and revenue
monthly_data_query = '''
WITH monthly_data AS (
    SELECT
        DATE_TRUNC('month', order_date) AS month,
        COUNT(order_id) AS total_orders,
        SUM(total_price) AS total_revenue
    FROM stg_sales
    GROUP BY DATE_TRUNC('month', order_date)
)
SELECT
    month,
    total_orders,
    total_revenue
FROM monthly_data
ORDER BY month;
'''

# Load the data into a DataFrame
monthly_data = pd.read_sql(monthly_data_query, engine)

#Plot Monthly Total Revenue Over Time
plt.figure(figsize=(10, 6))
sns.lineplot(data=monthly_data, x='month', y='total_revenue', marker='o')
plt.title('Monthly Total Revenue Over Time')
plt.xlabel('Month')
plt.ylabel('Total Revenue ($)')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

#Plot Monthly Total Orders Over Time
plt.figure(figsize=(10, 6))
sns.lineplot(data=monthly_data, x='month', y='total_orders', marker='o', color='green')
plt.title('Monthly Total Orders Over Time')
plt.xlabel('Month')
plt.ylabel('Total Orders')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# Query category sales data
category_sales_query = '''
WITH category_sales AS (
    SELECT
        p.category,
        SUM(s.quantity) AS total_sales,
        SUM(s.total_price) AS total_revenue,
        AVG(p.price) AS avg_price
    FROM stg_sales s
    JOIN stg_products p
    ON s.product_id = p.product_id
    GROUP BY p.category
)
SELECT
    category,
    total_sales,
    total_revenue,
    avg_price
FROM category_sales
ORDER BY total_revenue DESC;
'''

# Load the data into a DataFrame
category_sales_data = pd.read_sql(category_sales_query, engine)

#Plot Total Revenue by Category
plt.figure(figsize=(12, 7))
sns.barplot(data=category_sales_data, x='total_revenue', y='category', palette='Blues_d')
plt.title('Total Revenue by Product Category')
plt.xlabel('Total Revenue ($)')
plt.ylabel('Category')
plt.tight_layout()
plt.show()

# Query customer revenue data
customer_revenue_query = '''
WITH customer_revenue AS (
    SELECT
        customer_id,
        COUNT(order_id) AS total_orders,
        SUM(total_price) AS total_revenue,
        AVG(total_price) AS avg_order_value
    FROM stg_sales
    GROUP BY customer_id
)
SELECT
    customer_id,
    total_orders,
    total_revenue,
    avg_order_value
FROM customer_revenue
ORDER BY total_revenue DESC;
'''

# Load the data into a DataFrame
customer_revenue_data = pd.read_sql(customer_revenue_query, engine)

#Plot Top 10 Customers by Total Revenue
top_10_customers = customer_revenue_data.head(10)

plt.figure(figsize=(12, 7))
sns.barplot(data=top_10_customers, x='total_revenue', y='customer_id', palette='Purples_d')
plt.title('Top 10 Customers by Total Revenue')
plt.xlabel('Total Revenue ($)')
plt.ylabel('Customer ID')
plt.tight_layout()
plt.show()
